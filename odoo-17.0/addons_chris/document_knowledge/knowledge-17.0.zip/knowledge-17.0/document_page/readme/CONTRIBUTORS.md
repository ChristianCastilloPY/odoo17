- Gervais Naoussi \<<gervaisnaoussi@gmail.com>\>
- Maxime Chambreuil \<<mchambreuil@ursainfosystems.com>\>
- Iván Todorovich \<<ivan.todorovich@gmail.com>\>
- Jose Maria Alzaga \<<jose.alzaga@aselcis.com>\>
- Lois Rilo \<<lois.rilo@forgeflow.com>\>
- Simone Orsi \<<simone.orsi@camptocamp.com>\>
- [Tecnativa](https://www.tecnativa.com):
  - Ernesto Tejeda
  - Víctor Martínez

Trobz

- Dung Tran \<<dungtd@trobz.com>\>
- [Sygel](https://www.sygel.es):
  - Ángel García de la Chica Herrera
