To select the users that have access to a given document page
you need to open a document, go to the 'Security' tab and you have 3 options:
- Select a group: Only users with those groups will be able to see the page.
- Select any user: Only the selected users will be able to see the page.
- Do not select group or user: All users will be able to see the page.
