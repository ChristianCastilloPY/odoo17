- Manuel Regidor \<<manuel.regidor@sygel.es>\>
- Alberto Martínez \<<alberto.martinez@sygel.es>\>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Víctor Martínez
