This module allows to select which users groups have access to the
document pages.
