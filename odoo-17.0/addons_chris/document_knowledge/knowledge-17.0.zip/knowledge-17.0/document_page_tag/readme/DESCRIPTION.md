This module allows you to fill in keywords on your pages to simplify
finding them afterwards.
